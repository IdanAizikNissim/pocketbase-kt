/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("g75jcebf8gzzkl6")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "lq9f2v9w",
    "name": "file",
    "type": "file",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "mimeTypes": [],
      "thumbs": [],
      "maxSelect": 1,
      "maxSize": 5242880,
      "protected": true
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("g75jcebf8gzzkl6")

  // remove
  collection.schema.removeField("lq9f2v9w")

  return dao.saveCollection(collection)
})
